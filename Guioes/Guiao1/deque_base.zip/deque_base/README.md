### Build

```sh
gcc -c deque.c
gcc main.c deque.o -o main
```

### Run

```sh
./main
```
