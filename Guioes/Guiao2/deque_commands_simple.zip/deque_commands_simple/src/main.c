#include "deque.h"
#include "command_parser.h"

//==============
//Esta resolução mostra como exemplo uma deque que guarda valores do tipo int. 
//Atenção este exemplo lê apenas uma linha
//==============


/* Main */
int main(int argc, char **argv) {
    
    /*Definir de onde vou ler*/
    FILE* fp = NULL;

    if (argc < 2){
        fp=stdin;
    } else {
        char* filename = argv[1];
        fp = fopen(filename, "r");
        if (!fp){
            perror("Error");
            return 2;
        }
    }

    /*Ler uma linha*/
    char* line = NULL;
    size_t len;

    getline(&line, &len, fp);

    //Fazer parsing da linha para uma struct
    Cmd* command = parseLine(line);

    //Criar a deque
    Deque* deque = create();

    //Executar na deque
    processCommand(deque, command);

    //Libertar a memória da linha
    free(line);

    return 0;
}
