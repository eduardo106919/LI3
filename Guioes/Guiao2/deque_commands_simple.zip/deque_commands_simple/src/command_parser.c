#include "command_parser.h"
#include "deque.h"

/* Prints a pointer to int */
void printInt(void* i) {
    int* i_ = i;
    printf("%d", *i_);
}

int string_to_int(char *line){
    char *ptr;
    int value = (int) strtol(line, &ptr,10);
    if(*ptr && *ptr != '\n'){
        perror("String not converted to int successfully: ");
        printf("String: %s\n", line);
        exit(-1);
    }
    return value;
}

void processCommand(Deque *deque, Cmd *cmd){
    int * num;
    if(!strcmp(cmd->command, "PRINT")){
        printDeque(deque, printInt);
    } else if(!strcmp(cmd->command, "PUSH")){
        for(int i = 0; i < cmd->nargs; i++){
            num = malloc(sizeof(int));
            *num = cmd->args[i];
            push(deque, (void *) num);
        }
    } else if(!strcmp(cmd->command, "PUSH_FRONT")){
        for(int i = 0; i < cmd->nargs; i++){
            num = malloc(sizeof(int));
            *num = cmd->args[i];
            pushFront(deque, (void *) num);
        }
    } else if(!strcmp(cmd->command, "POP")){
        num = (int *)pop(deque);
        if(num){
            printf("%d\n", *num);
            free(num);
        } else {
            puts("EMPTY");
        }
    } else if(!strcmp(cmd->command, "POP_FRONT")){
        num = popFront(deque);
        if(num){
            printf("%d\n", *num);
            free(num);
        } else {
            puts("EMPTY");
        }
    } else if(!strcmp(cmd->command, "REVERSE")){
        reverse(deque);
    } else if(!strcmp(cmd->command, "SIZE")){
        int deque_size = size(deque);
        printf("%d\n", deque_size);
    } else {
        printf("Command not recognized\n");//, cmd->command);
    }
    printDeque(deque,printInt);
}

Cmd* parseLine(char* line){
    Cmd *cmd = malloc(sizeof(Cmd));
    cmd->command = NULL;
    cmd->args=NULL;
    cmd->nargs=0;
    char *lineCopy = strdup(line);
    char *token = strsep(&lineCopy, " \n");
    
    while(token){
        if(strlen(token) > 0){
            if(!cmd->command){
                cmd->command = strdup(token);
            } else {
                if(!cmd->args){
                    cmd->args = malloc(sizeof(int));
                } else {
                    cmd->args = realloc(cmd->args, 
                    sizeof(int) * (cmd->nargs + 1)); //Not very efficient, but will do
                }
                cmd->args[cmd->nargs] = string_to_int(token);
                cmd->nargs++;
            } 
        }
        token = strsep(&lineCopy, " ");
    }

    return cmd;
}

